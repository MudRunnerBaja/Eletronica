import PySimpleGUI as sg
import time
from Comunicação_Serial import vel

#Código criado por Lucas Braga :P


#Variaveis para pegar do serial
rpm = 0
comb = 'verde'
vel = 0

x = 0

#Variaveis de tempo
current_time = 0
last_time = 0

#auxiliares para saber tempo de permanencia em determinado nivel de combustivel
auxr = 0
auxy = 0
auxg = 0

sg.theme('DarkBlue15')

#Layouts secundarios dos frames
frame_comb = [
    [sg.Text('')],
    [sg.Text("     "), sg.Radio("Vermelho", 'radio', size=(20, 1), text_color=('red'), default=True, key=('ledr'))],
    [sg.Text('')],
    [sg.Text("     "), sg.Radio("Amarelo", 'radio', size=(20, 1), text_color=('yellow'), default=False, key=('ledy'))],
    [sg.Text('')],
    [sg.Text("     "), sg.Radio("Verde", 'radio', size=(20, 1), text_color=('green'), default=False, key=('ledg'))],
    [sg.Text('')],
    [sg.Text('Rendimento: ')],
    [sg.Text('',key=('rendimento'),text_color='white',size=(20,1))],
    [sg.Text('',key=('tempo'),text_color='white',size=(20,1))]
]

frame_rpm = [
[sg.Text(rpm,size=(4,1),font=('Seven Segment',100),text_color=('red'),justification=('right')),sg.Text('RPM',size=(3,1),text_color='red',font=('Seven Segment',40),justification=('left'))],
[sg.ProgressBar(5000, orientation='h', size=(20, 20), key=('progressbar'),bar_color=('yellow','RoyalBlue3')),sg.Button("Increment", key=("increment"))],
[sg.Text('0    1000    2000    3000    4000    5000')]
]

frame_vel = [
    [sg.Text(vel,size=(2,1),font=('Seven Segment',100),text_color=('red'),justification=('right')),sg.Text('Km/h',size=(4,1),text_color='red',font=('Seven Segment',40),justification=('left'))],
    [sg.ProgressBar(50, orientation='h', size=(20, 20), key=('progressbar2'),bar_color=('yellow','RoyalBlue3')),sg.Button("Increment2", key=("increment2"))],
    [sg.Text('0   5  10  15  20  25  30  35  40  45  50')]
]

frame_tempo = [
    [sg.Text('Tempo Total: ',font=(None,10)),sg.Text('      Tempo desde a ultima mudança: ',font=(None,10))],
    [sg.Text(size=(8, 2), font=('Helvetica', 20), justification='center', key='text1'),sg.Text(size=(8, 2), font=('Helvetica', 20), justification='center', key='text2')]
]

#Layout principal
layout = [
    [sg.Frame('Nível de Combustível',frame_comb),sg.Frame('Rotação do motor',frame_rpm),sg.Frame('Velocidade',frame_vel)],
    [sg.Text('',size=(30,1)),sg.Frame('Controle',frame_tempo)]
     ]

#Inicialização da janela
window = sg.Window('Sistema Supervisório - Equipe Mud Runner BAJA',layout)

#Inicialização das barras
progress_bar = window['progressbar']
progress_bar2 = window['progressbar2']

#Tempo
start_time = int(round(time.time() * 100))

window.finalize()

while True:
    #Pegar eventos da janela
    event, values = window.read(timeout=10)
    #calculo de tempo
    current_time = int(round(time.time() * 100)) - start_time

    if event == ('increment2'):
        x += 10
        progress_bar2.UpdateBar(x)

    # Lógica do Combustível
    if comb == 'verde':
        #logica pra guardar o tempo de permanencia em determinado nivel
        if auxg == 0:
            last_time = current_time
        else:
            auxr = 0
            auxy = 0
        auxg += 1

        #Atualização de dados
        window.FindElement('ledg').Update(True)
        window['rendimento']('3,0L - 2,5L')
        window.FindElement('tempo').Update('90 - 180 minutos')

    elif comb == 'amarelo':
        if auxy == 0:
            last_time = current_time
        else:
            auxr = 0
            auxg = 0
        auxy += 1
        window.FindElement('ledy').Update(True)
        window.FindElement('rendimento').Update('2,5L - 1,0L')
        window.FindElement('tempo').Update('30 - 90 minutos')
    else:
        if auxr == 0:
            last_time = current_time
        else:
            auxg = 0
            auxy = 0
        auxr += 1
        window.FindElement('ledr').Update(True)
        window.FindElement('rendimento').Update('1,0L - 0,0L')
        window.FindElement('tempo').Update('30 - 0 minutos')

    #atualização de timers
    #tempo total
    window.FindElement('text1').Update('{:02d}:{:02d}.{:02d}'.format((current_time // 100) // 60,
                                                                    (current_time // 100) % 60,
                                                                    current_time % 100))
    #tempo da ultima mudanca de comb
    window.FindElement('text2').Update('{:02d}:{:02d}.{:02d}'.format(((current_time - last_time) // 100) // 60,
                                                                    ((current_time - last_time)// 100) % 60,
                                                                     (current_time - last_time) % 100))

