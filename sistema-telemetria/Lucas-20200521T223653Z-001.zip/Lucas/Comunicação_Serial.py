import serial

ser = serial.Serial('COM4',9600,timeout=1)
inicio = False
dadoRecebido = ""
vel = ''
rpm = ''
comb = ''
rpmaux =''
velaux = ''
combaux = ''
validavel = False
validarpm = False
validacomb = False

while True:
    # Comunicação Serial

    # verificando qual dado está entrando
    id = ser.read().decode('ascii')
    if id == '$':  # velocidade
        validavel = True
    if id == '%':  # rpm
        validarpm = True
    if id == '&':  # combustivel
        validacomb = True

    # Recebendo dados da velocidade
    while validavel == True:
        dado = ser.read().decode('ascii')
        if dado == '#':
            vel = velaux
            velaux = ''
            print('Velocidade: '+vel)
            break
        else:
            velaux += dado

    # Recebendo dados do rpm
    while validarpm == True:
        dado = ser.read().decode('ascii')
        if dado == '#':
            rpm = rpmaux
            rpmaux = ''
            print('Rpm: ' + rpm)

            break
        else:
            rpmaux += dado

    # Recebendo dados do combustivel
    while validacomb == True:
        dado = ser.read().decode('ascii')
        if dado == '#':
            comb = combaux
            combaux =''
            print('Combustivel: ' +comb)
            break
        else:
            combaux += dado